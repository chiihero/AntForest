---
name: Bug 反馈 / Bug report
about: Create a report to help us improve
title: 这是标题！This is the title!
labels: bug
assignees: ''

---

[或许你遇到的问题已经在 wiki 里有说明了](https://github.com/pansong291/XQuickEnergy/wiki)  

[请先阅读此反馈 BUG 的注意事项，再提交](https://github.com/pansong291/XQuickEnergy/issues/25)
