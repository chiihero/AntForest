package com.chii.antforest.ui;

public class AlipayId {
    public String name;
    public String id;
}
