package com.chii.antforest.util;

import android.content.Context;

public class ContextUtil {
    public static Context context;

    public static Context getContext() {
        return context;
    }

}
